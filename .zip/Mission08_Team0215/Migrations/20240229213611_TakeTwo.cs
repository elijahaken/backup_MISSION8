﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Mission08_Team0215.Migrations
{
    /// <inheritdoc />
    public partial class TakeTwo : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
